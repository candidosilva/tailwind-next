export default function Home() {
  return (
    <button class="bg-sky-700 px-4 py-2 text-white hover:bg-sky-800 sm:px-8 sm:py-3">
      Login
    </button>
  );
}
